import test from '@playwright/test'

let access_Token:any
let instance_Url:any
let token_type:any
let SF_id:any

test("SF E2E",async({request})=>{

//generate token

const tokenResponse=await request.post('https://login.salesforce.com/services/oauth2/token',{
    headers:{
        "Content-Type":"application/x-www-form-urlencoded"
    },

    form:{
        "grant_type":"password",
"username":"manikandanleo4922@agentforce.com",
"password":"India@2026",
"client_id":"3MVG9dAEux2v1sLs_5LgrWbWWJbMYKRgBajBibwGyik0pC_tXNFGsk6aV8h1owvGj6hsaxRWhzGX5WP1O87h5",
"client_secret":"EE7E666EF8204C869125AC8160C78B0F93277C544B84F8B89A0D59AD9FB3AD1C"

    }
})

const res=await tokenResponse.json()
console.log(res)
access_Token=res.access_token
instance_Url=res.instance_url
token_type=res.token_type


//post request -> Account

const accResponse=await request.post(`${instance_Url}/services/data/v66.0/sobjects/Account`,{

    headers:{
        "Content-Type":"application/json",
        "Authorization":`${token_type} ${access_Token}`
    },
    data:{
        "name":"TestLeaf"
    }
})

const accRes=await accResponse.json()
console.log(accRes)
SF_id=accRes.id



})