import test, { expect } from '@playwright/test'

let user='admin'
let pass='slBB0^k9l^YU'
let login=`${user}:${pass}`
let loginValue=btoa(login)
console.log(loginValue)

let sys_ID:any


test("SN Create Incident",async({request})=>{

    //post(endpoint uri, header info)
    const postResponse= await request.post('https://dev362368.service-now.com/api/now/table/incident',{

headers:{
    //contentType, auth
    "Content-Type":"application/json",
    "Authorization":`Basic ${loginValue}`
},

//request body -> Data
data:{

    "short_description": "Playwright with API uisng Request fixture"
}
    })

    //validation 
    let response=await postResponse.json()
    sys_ID= response.result.sys_id
    console.log(sys_ID)

    console.log(postResponse.status())
    expect(postResponse.status()).toBe(201)


    //Get Request
    const getResponse=await request.get(`https://dev362368.service-now.com/api/now/table/incident/${sys_ID}`,{


        headers:{
    //contentType, auth
    "Content-Type":"application/json",
    "Authorization":`Basic ${loginValue}`
}
    })
    const res= await getResponse.json()
    console.log(res)

//patch -> header,data -> status

//delete -> header -> status


})
